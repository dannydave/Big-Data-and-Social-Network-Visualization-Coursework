library(readr)
library(dplyr)
library(ggplot2)
library(tidytext)
library(tidyr)
library(stringr)
library(scales)
library(tidyverse)
# 2.2 Writing an R Function showing the change of word frequency over time---------------

# Function to plot the proportion of given words trends over time for a single word

plot_word_trends <- function(data, selected_words, na.rm = TRUE) {

  stopifnot(is.character(selected_words)) # Check if 'selected_words' is a character vector

  data$published <- as.Date(data$published) # Convert 'published' to Date class if not already

  # Tokenize the articles, remove stopwords, and count word occurrences
  word_counts <- data %>%
    unnest_tokens(word, articles) %>%
    anti_join(get_stopwords(), by = "word") %>%
    count(published, word, sort = TRUE) %>%
    ungroup()

  # Calculate the total number of words per date
  total_words <- word_counts %>%
    group_by(published) %>%
    summarize(total = sum(n), .groups = 'drop')

  # Join the counts with the total words and calculate word proportions
  word_frequencies <- word_counts %>%
    inner_join(total_words, by = "published") %>%
    mutate(proportion = n / total) %>%
    filter(word %in% selected_words)

  # Define colors for the words
  colors <- scales::hue_pal()(length(selected_words))

  # Plot the change of word frequency over time in 2022
  ggplot(word_frequencies, aes(x = published, y = proportion, colour = word, group = word)) +
    geom_point(size = 1.5) +
    geom_smooth(size = 1.2, se = TRUE) +
    geom_smooth(method = "lm", size = 1.2, se = FALSE, col = "black") + # Add a regression line
    scale_x_date(labels = date_format("%b")) + # Format x-axis labels
    scale_y_continuous(labels = scales::percent_format(accuracy = 0.5)) +
    scale_color_manual(values = colors) + # Assign unique colors
    labs(x = "Article Date", y = "Percentage of words in Ukraine war articles in 2022", color = "Word", title = "Change of Word Frequency Over Time in 2022") +
    facet_wrap(~ word, scales = "free") +
    theme_minimal() +
    theme(
      legend.position = "none",
      panel.border = element_rect(color = "black", fill = NA, size = 0.5), # Border for facet_wrap
      strip.background = element_rect(color = "black", fill = "lightyellow"),
      strip.text = element_text(color = "black", face = "bold", hjust = 0.5), # Title text color, style and justification
      axis.ticks = element_line(color = "black"), # Add black ticks to the axes
      axis.text = element_text(face = "bold"),
      axis.title = element_text(face = "bold"))
}
