## ----include=FALSE------------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
library(readr)
library(dplyr)
library(ggplot2)
library(tidytext)
library(tidyr)
library(stringr)
library(scales)
library(tidyverse)
library(UkraineWordTrends)

## ----echo=FALSE, message=FALSE, warning=FALSE---------------------------------
# 2.1 Data Preparation-------------------------------------------

# Read in the data using read_csv from the readr package and include a new variable journal where the articles were published on
NYT <- read_csv("NYT_Russia_Ukraine.csv") %>%
  mutate(journal = 'NYT')

Guardian <- read_csv("Guardians_Russia_Ukraine.csv") %>%
  mutate(journal = 'Guardian')

# Combine both data
combined_data <- bind_rows(Guardian, NYT)
combined_data

# Write combined data to CSV
write_csv(combined_data, "Combined_Guardian_NYT.csv")


## ----echo=FALSE, message=FALSE, warning=FALSE---------------------------------
# 2.2 Writing an R Function showing the change of word frequency over time---------------
# Read in the data using read_csv form the readr package
b_d <- read_csv("invented_data_for_illustration.csv")
# Work out percentages for each date using the dplr package
b_p <- b_d %>%
  count(date, word) %>%
  group_by(date) %>%
  mutate(p = n / sum(n))
b_p

## ----echo=FALSE, fig.height=5, fig.width=7, message=FALSE, warning=FALSE------
# Plot the contents of b_p using ggplot2
#
ggplot(b_p,
       aes(x = date, y = p, colour = word, group = word)) +
  geom_point() +
  geom_line() +
  labs(y = "Percentage of words") +
  facet_wrap(~ word) +
  scale_x_date(labels = date_format("%d %b %y"),
               limits = c(as.Date("2021-10-26")+0.5,
                          as.Date("2021-10-29")-0.5)) +
  theme(legend.position = "none")

## ----message=FALSE, warning=FALSE, include=FALSE------------------------------
# Function to plot the proportion of given words trends over time for a single word

plot_word_trends <- function(data, selected_words, na.rm = TRUE) {
  
  stopifnot(is.character(selected_words)) # Check if 'selected_words' is a character vector
  
  data$published <- as.Date(data$published) # Convert 'published' to Date class if not already
  
  # Tokenize the articles, remove stopwords, and count word occurrences
  word_counts <- data %>%
    unnest_tokens(word, articles) %>%
    anti_join(get_stopwords(), by = "word") %>%
    count(published, word, sort = TRUE) %>%
    ungroup()
  
  # Calculate the total number of words per date
  total_words <- word_counts %>%
    group_by(published) %>%
    summarize(total = sum(n), .groups = 'drop')
  
  # Join the counts with the total words and calculate word proportions
  word_frequencies <- word_counts %>%
    inner_join(total_words, by = "published") %>%
    mutate(proportion = n / total) %>%
    filter(word %in% selected_words)
  
  # Define colors for the words
  colors <- scales::hue_pal()(length(selected_words))
  
  # Plot the change of word frequency over time in 2022
  ggplot(word_frequencies, aes(x = published, y = proportion, colour = word, group = word)) +
    geom_point(size = 1.5) +
    geom_smooth(size = 1.2, se = TRUE) +
    geom_smooth(method = "lm", size = 1.2, se = FALSE, col = "black") + # Add a regression line
    scale_x_date(labels = date_format("%b")) + # Format x-axis labels
    scale_y_continuous(labels = scales::percent_format(accuracy = 0.5)) +
    scale_color_manual(values = colors) + # Assign unique colors
    labs(x = "Article Date", y = "Percentage of words in Ukraine war articles in 2022", color = "Word", title = "Change of Word Frequency Over Time in 2022") +
    facet_wrap(~ word, scales = "free") +
    theme_minimal() +
    theme(
      legend.position = "none",
      panel.border = element_rect(color = "black", fill = NA, size = 0.5), # Border for facet_wrap
      strip.background = element_rect(color = "black", fill = "lightyellow"),
      strip.text = element_text(color = "black", face = "bold", hjust = 0.5), # Title text color, style and justification
      axis.ticks = element_line(color = "black"), # Add black ticks to the axes
      axis.text = element_text(face = "bold"),
      axis.title = element_text(face = "bold")) 
}

## ----echo=FALSE, fig.height=6, fig.width=7, message=FALSE, warning=FALSE------
# Apply the function
# Read the combined data from CSV
combined_data <- read_csv("Combined_Guardian_NYT.csv")

# Define sets of selected words and apply the function for each set of selected words
selected_words <- c("civilians")
plot_word_trends(combined_data, selected_words)


## ----echo=FALSE, fig.height=7, fig.width=7, message=FALSE, warning=FALSE------
selected_words <- c("country", "putin", "zelensky")
plot_word_trends(combined_data, selected_words)


## ----echo=FALSE, fig.height=9, fig.width=7, message=FALSE, warning=FALSE------
selected_words <- c("biden", "nato", "russia","ukraine", "war", "weapons")
plot_word_trends(combined_data, selected_words)

## ----echo=FALSE, message=FALSE, warning=FALSE---------------------------------
# 2.3 Plotting the Words with Highest tf-idf Value---------------------------

# Work out tf, idf and tf_idf indexes
b_t <- b_d %>%
  count(location, word) %>%
  bind_tf_idf(word, location, n) %>%
  arrange(desc(tf_idf))
b_t

## ----message=FALSE, warning=FALSE, include=FALSE------------------------------
# Tokenize and remove stopwords
tokenized_data <- combined_data %>%
  unnest_tokens(word, articles) %>%
  anti_join(get_stopwords(), by = "word") %>%
  filter(!str_detect(word, "\\d+")) %>%
  select(-published, -headlines)

# Work out tf, idf, and tf_idf indexes efficiently
tf_idf_data <- tokenized_data %>%
  count(journal, word) %>%
  bind_tf_idf(word, journal, n) %>%
  arrange(journal, desc(tf_idf)) %>%
  group_by(journal) %>%
  top_n(10, tf_idf) # More efficient way to get top 10 tf-idf words for each journal


## ----echo=FALSE, fig.height=9, fig.width=7, message=FALSE, warning=FALSE------
# Plot top tf-idf words, grouped by journal.
tf_idf_data %>%
  group_by(journal) %>%
  top_n(10, tf_idf) %>%
  ungroup() %>%
  arrange(journal, tf_idf) %>%  # Arrange in ascending order
  ggplot(aes(reorder(word, tf_idf), tf_idf, fill = journal)) +
  geom_col(show.legend = FALSE) +
  coord_flip() +
  scale_fill_manual(values = rainbow(length(unique(tf_idf_data$journal)))) +
  facet_wrap(~journal, scales = "free_y") +
  labs(title = "Highest tf-idf Words in Ukraine war articles in 2022",
       y = "tf-idf index",
       x = NULL) +
  theme(axis.text = element_text(size = 10, color = "black"),
        axis.title = element_text(size = 12, color = "black", face = "bold"))



## ----message=FALSE, warning=FALSE, include=FALSE------------------------------
# 2.4 Zipf's Law----------------------------------------------------

# Tokenize the articles without removing stopwords
# This code uses unnest_tokens from the tidytext package to tokenize the articles, converting each article into a tidy data frame where each row represents a word in an article.
tokenized_data <- combined_data %>%
  unnest_tokens(word, articles) %>%
  filter(!str_detect(word, "\\d+")) %>%
  select(-published, -headlines)

# Calculate term frequency (tf) using bind_tf_idf
# The code calculates the term frequency (tf) using the bind_tf_idf function, which computes the term frequency-inverse document frequency. The data is then arranged by journal and term frequency in descending order.
tf_data <- tokenized_data %>%
  count(journal, word) %>%
  bind_tf_idf(word, journal, n) %>%
  arrange(journal, desc(tf))

# Calculate rank for each word within each journal
# The code groups the data by journal and calculates the rank for each word within each journal based on term frequency.
tf_data <- tf_data %>%
  group_by(journal) %>%
  mutate(rank = row_number())

## ----echo=FALSE, fig.height=6, fig.width=7, message=FALSE, warning=FALSE------
# Plot Zipf's law on a log-log scale
# The code creates a log-log plot using ggplot2 with term frequency on the y-axis, world rank on the x-axis, and different colors for each journal.
ggplot(tf_data, aes(x = rank, y = tf, colour = journal)) +
  geom_line(size = 1.5) +
  scale_x_continuous(name = "Word rank", trans = 'log10') +
  scale_y_continuous(name = "Term Frequency(tf)", trans = 'log10', labels = function(x) format(x, scientific = FALSE)) +
  ggtitle("Zipf's Law for Ukraine war articles in 2022") +
  theme_minimal() +
  scale_color_manual(values = c("#eb3f42", "#2ff5bd")) +
  theme_minimal() +
  theme(panel.border = element_rect(color = "black", fill = NA),
        axis.text = element_text(size = 10, color = "black"),
        axis.title = element_text(size = 12, color = "black", face = "bold"))



## ----echo=FALSE, fig.height=6, fig.width=7, message=FALSE, warning=FALSE------
# Plot Zipf's law with regression line
# The code adds a linear regression line to the log-log plot, illustrating the relationship between log(rank) and log(term frequency). The geom_smooth function with method = "lm" is used to fit a linear model, and labs is used to provide labels for the plot.
ggplot(tf_data, aes(x = rank, y = tf, colour = journal)) +
  geom_line(size = 1.5) +
  scale_x_continuous(name = "Word rank", trans = 'log10') +
  scale_y_continuous(name = "Term Frequency(tf)", trans = 'log10', labels = function(x) format(x, scientific = FALSE)) +
  geom_smooth(method = "lm", se = FALSE, color = "black") +
  ggtitle("Zipf's Law for Ukraine war articles in 2022") +
  scale_color_manual(values = c("#eb3f42", "#2ff5bd")) +
  theme_minimal() +
  theme(panel.border = element_rect(color = "black", fill = NA),
        axis.text = element_text(size = 10, color = "black"),
        axis.title = element_text(size = 12, color = "black", face = "bold"))

